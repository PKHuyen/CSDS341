module LibraryManagementSystem {
    requires javafx.controls;
    requires javafx.graphics;
    requires javafx.fxml;
    requires java.sql;

    opens test.librarymanagementsystem;
}